import os

# =========================
# CRIAÇÃO DOS ARQUIVOS
# =========================

arquivos = [
    "usuarios.txt",
    "videos.txt",
    "curtidas.txt",
    "favoritos.txt"
]

for arquivo in arquivos:

    if not os.path.exists(arquivo):
        open(arquivo, "w", encoding="utf-8").close()

# =========================
# FILMES PADRÃO
# =========================

with open("videos.txt", "r", encoding="utf-8") as arquivo:
    conteudo = arquivo.read()

if conteudo == "":

    with open("videos.txt", "w", encoding="utf-8") as arquivo:

        arquivo.write(
"""1;Interestelar;Filme de ficção científica sobre viagens espaciais e buracos negros;2014
2;Stranger Things;Série de suspense e ficção científica com criaturas do mundo invertido;2016
3;Vingadores Ultimato;Filme de ação e super-heróis da Marvel;2019
4;Breaking Bad;Série dramática sobre um professor que entra no mundo do crime;2008
5;Avatar;Filme de ficção científica com aventura no planeta Pandora;2009
6;Batman O Cavaleiro das Trevas;Filme de ação sobre o herói Batman enfrentando o Coringa;2008
7;The Last of Us;Série pós-apocalíptica baseada no jogo de videogame;2023
8;Homem-Aranha Sem Volta Para Casa;Filme de ação e aventura do universo Marvel;2021
9;La Casa de Papel;Série espanhola sobre assaltos e estratégia criminal;2017
10;Titanic;Filme romântico e dramático sobre o naufrágio do Titanic;1997
"""
        )

# =========================
# USUÁRIOS
# =========================

def cadastrar_usuario():

    print("\n=== CADASTRO ===")

    usuario = input("Usuário: ")
    senha = input("Senha: ")

    with open("usuarios.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 2:

                u = dados[0]

                if usuario == u:
                    print("Usuário já existe.")
                    return

    with open("usuarios.txt", "a", encoding="utf-8") as arquivo:
        arquivo.write(f"{usuario};{senha}\n")

    print("Usuário cadastrado!")


def login():

    print("\n=== LOGIN ===")

    usuario = input("Usuário: ")
    senha = input("Senha: ")

    with open("usuarios.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 2:

                u = dados[0]
                s = dados[1]

                if usuario == u and senha == s:
                    print("Login realizado!")
                    return usuario

    print("Usuário ou senha inválidos.")
    return None

# =========================
# CURTIDAS
# =========================

def quantidade_curtidas(id_video):

    curtidas = 0

    with open("curtidas.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 2:

                video = dados[1]

                if video == id_video:
                    curtidas += 1

    return curtidas


def curtir_video(usuario):

    print("\n=== CURTIR VÍDEO ===")

    id_video = input("ID do vídeo: ")

    with open("curtidas.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 2:

                u = dados[0]
                video = dados[1]

                if u == usuario and video == id_video:
                    print("Você já curtiu este vídeo.")
                    return

    with open("curtidas.txt", "a", encoding="utf-8") as arquivo:
        arquivo.write(f"{usuario};{id_video}\n")

    print("Vídeo curtido!")


def descurtir_video(usuario):

    print("\n=== DESCURTIR VÍDEO ===")

    id_video = input("ID do vídeo: ")

    curtiu = False

    with open("curtidas.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 2:

                u = dados[0]
                video = dados[1]

                if u == usuario and video == id_video:
                    curtiu = True
                    break

    if not curtiu:
        print("Você ainda não curtiu este vídeo.")
        return

    with open("curtidas.txt", "r", encoding="utf-8") as arquivo:
        linhas = arquivo.readlines()

    with open("curtidas.txt", "w", encoding="utf-8") as arquivo:

        removido = False

        for linha in linhas:

            dados = linha.strip().split(";")

            if len(dados) >= 2:

                u = dados[0]
                video = dados[1]

                if (
                    u == usuario
                    and video == id_video
                    and not removido
                ):

                    removido = True

                else:
                    arquivo.write(linha)

    print("Vídeo descurtido!")

# =========================
# VÍDEOS
# =========================

def listar_videos():

    print("\n=== LISTA DE VÍDEOS ===")

    with open("videos.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 4:

                id_video = dados[0]
                titulo = dados[1]
                descricao = dados[2]
                ano = dados[3]

                curtidas = quantidade_curtidas(id_video)

                print(f"""
ID: {id_video}
Título: {titulo}
Descrição: {descricao}
Ano: {ano}
Curtidas: {curtidas}
""")


def buscar_video():

    print("\n=== BUSCAR VÍDEO ===")

    busca = input("Digite o nome: ")

    encontrou = False

    with open("videos.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 4:

                id_video = dados[0]
                titulo = dados[1]
                descricao = dados[2]
                ano = dados[3]

                if busca.lower() in titulo.lower():

                    encontrou = True

                    curtidas = quantidade_curtidas(id_video)

                    print(f"""
ID: {id_video}
Título: {titulo}
Descrição: {descricao}
Ano: {ano}
Curtidas: {curtidas}
""")

    if not encontrou:
        print("Nenhum vídeo encontrado.")


def ranking_videos():

    print("\n=== RANKING DOS MAIS CURTIDOS ===")

    ranking = []

    with open("videos.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 4:

                id_video = dados[0]
                titulo = dados[1]
                ano = dados[3]

                curtidas = quantidade_curtidas(id_video)

                ranking.append((titulo, ano, curtidas))

    ranking.sort(key=lambda x: x[2], reverse=True)

    posicao = 1

    for video in ranking:

        print(f"""
{posicao}º Lugar
Vídeo: {video[0]}
Ano: {video[1]}
Curtidas: {video[2]}
""")

        posicao += 1

# =========================
# PLAYLIST
# =========================

def criar_lista(usuario):

    print("\n=== CRIAR PLAYLIST ===")

    nome_lista = input("Nome da playlist: ")

    with open("favoritos.txt", "a", encoding="utf-8") as arquivo:
        arquivo.write(f"{usuario};{nome_lista};\n")

    print("Playlist criada!")


def listar_favoritos(usuario):

    print("\n=== PLAYLISTS ===")

    encontrou = False

    with open("favoritos.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 3:

                u = dados[0]
                lista = dados[1]
                videos = dados[2]

                if usuario == u:

                    encontrou = True

                    print(f"""
Playlist: {lista}
Vídeos Favoritos: {videos}
""")

    if not encontrou:
        print("Nenhuma playlist encontrada.")


def adicionar_favorito(usuario):

    print("\n=== ADICIONAR FAVORITO ===")

    nome_lista = input("Playlist: ")
    id_video = input("ID do vídeo: ")

    # =========================
    # VERIFICA SE O VÍDEO EXISTE
    # =========================

    video_existe = False

    with open("videos.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 4:

                id_existente = dados[0]

                if id_video == id_existente:
                    video_existe = True
                    break

    # SE O ID NÃO EXISTIR
    if not video_existe:
        print("ID do vídeo não encontrado.")
        return

    # =========================
    # ADICIONAR NA PLAYLIST
    # =========================

    linhas = []

    with open("favoritos.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 3:

                u = dados[0]
                lista = dados[1]
                videos = dados[2]

                if usuario == u and lista == nome_lista:

                    lista_videos = []

                    if videos != "":
                        lista_videos = videos.split(",")

                    # VERIFICA SE JÁ ESTÁ NA PLAYLIST
                    if id_video in lista_videos:
                        print("Vídeo já está na playlist.")

                    else:

                        # ADICIONA O VÍDEO
                        if videos == "":
                            videos = id_video
                        else:
                            videos += f",{id_video}"

                        print("Vídeo adicionado!")

                linhas.append(f"{u};{lista};{videos}\n")

    with open("favoritos.txt", "w", encoding="utf-8") as arquivo:
        arquivo.writelines(linhas)

def remover_favorito(usuario):

    print("\n=== REMOVER FAVORITO ===")

    nome_lista = input("Playlist: ")
    id_video = input("ID do vídeo: ")

    linhas = []

    with open("favoritos.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 3:

                u = dados[0]
                lista = dados[1]
                videos = dados[2]

                if usuario == u and lista == nome_lista:

                    lista_videos = videos.split(",")

                    if id_video in lista_videos:
                        lista_videos.remove(id_video)

                    videos = ",".join(lista_videos)

                linhas.append(f"{u};{lista};{videos}\n")

    with open("favoritos.txt", "w", encoding="utf-8") as arquivo:
        arquivo.writelines(linhas)

    print("Vídeo removido!")


def excluir_lista(usuario):

    print("\n=== EXCLUIR PLAYLIST ===")

    nome_lista = input("Nome da playlist: ")

    linhas = []

    with open("favoritos.txt", "r", encoding="utf-8") as arquivo:

        for linha in arquivo:

            dados = linha.strip().split(";")

            if len(dados) >= 3:

                u = dados[0]
                lista = dados[1]

                if not (usuario == u and lista == nome_lista):
                    linhas.append(linha)

    with open("favoritos.txt", "w", encoding="utf-8") as arquivo:
        arquivo.writelines(linhas)

    print("Playlist excluída!")

# =========================
# MENU PRINCIPAL
# =========================

while True:

    print("""
=========================
         FEItv
=========================

1 - Cadastrar usuário
2 - Login
0 - Sair
""")

    opcao = input("Escolha: ")

    if opcao == "1":
        cadastrar_usuario()

    elif opcao == "2":

        usuario_logado = login()

        if usuario_logado:

            while True:

                print(f"""
=========================
Usuário: {usuario_logado}
=========================

1 - Listar vídeos
2 - Buscar vídeo
3 - Curtir / Descurtir
4 - Ranking dos mais curtidos
5 - Playlist
6 - Logout
""")

                menu = input("Escolha: ")

                # LISTAR VÍDEOS
                if menu == "1":
                    listar_videos()

                # BUSCAR VÍDEO
                elif menu == "2":
                    buscar_video()

                # CURTIR / DESCURTIR
                elif menu == "3":

                    while True:

                        print("""
=========================
   CURTIR / DESCURTIR
=========================

1 - Curtir vídeo
2 - Descurtir vídeo
0 - Voltar
""")

                        opcao_curtida = input("Escolha: ")

                        if opcao_curtida == "1":
                            curtir_video(usuario_logado)

                        elif opcao_curtida == "2":
                            descurtir_video(usuario_logado)

                        elif opcao_curtida == "0":
                            break

                        else:
                            print("Opção inválida.")

                # RANKING
                elif menu == "4":
                    ranking_videos()

                # PLAYLIST
                elif menu == "5":

                    while True:

                        print("""
=========================
        PLAYLIST
=========================

1 - Criar playlist
2 - Adicionar favoritos
3 - Remover favoritos
4 - Ver playlist
5 - Excluir playlist
0 - Voltar
""")

                        playlist = input("Escolha: ")

                        if playlist == "1":
                            criar_lista(usuario_logado)

                        elif playlist == "2":
                            adicionar_favorito(usuario_logado)

                        elif playlist == "3":
                            remover_favorito(usuario_logado)

                        elif playlist == "4":
                            listar_favoritos(usuario_logado)

                        elif playlist == "5":
                            excluir_lista(usuario_logado)

                        elif playlist == "0":
                            break

                        else:
                            print("Opção inválida.")

                # LOGOUT
                elif menu == "6":
                    print("Logout realizado.")
                    break

                else:
                    print("Opção inválida.")

    elif opcao == "0":
        print("Sistema encerrado.")
        break

    else:
        print("Opção inválida.")